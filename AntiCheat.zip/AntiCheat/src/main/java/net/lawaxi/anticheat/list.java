package net.lawaxi.anticheat;

import net.minecraft.entity.Entity;

import java.util.HashMap;
import java.util.Map;

public class list {
    public static Map<Entity, Double> entityy = new HashMap();
}
