package net.lawaxi.anticheat.mixin;

import com.google.common.collect.Sets;
import net.lawaxi.anticheat.list;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.MovementType;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.passive.StriderEntity;
import net.minecraft.entity.vehicle.BoatEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import javax.annotation.Nullable;
import java.util.Set;

@Mixin(Entity.class)
public abstract class EntityMixin {

	@Shadow public abstract boolean equals(Object o);

	@Shadow protected abstract void collectPassengers(boolean playersOnly, Set<Entity> output);

	@Shadow public abstract void move(MovementType type, Vec3d movement);

	@Shadow private Box entityBounds;

	@Shadow protected int ridingCooldown;

	@Shadow @Nullable public abstract Entity getVehicle();

	@Shadow public World world;

	@Shadow public abstract BlockPos getBlockPos();

	@Shadow protected abstract BlockState getLandingBlockState();

	@Shadow public abstract boolean hasVehicle();

	@Shadow public abstract boolean isInLava();

	@Shadow protected boolean onGround;

	@Inject(at = @At("HEAD"), method = "updatePosition")
	private void boatfly(CallbackInfo info) {

		ClientPlayerEntity player = MinecraftClient.getInstance().player;

		if(this.equals(player))
		{
			Entity boat = player.getRootVehicle();
			if(boat!=null)
			{
				if(MinecraftClient.getInstance().options.keyJump.isPressed())
				{
                    boat.setVelocity(new Vec3d(boat.getVelocity().x, 0.3, boat.getVelocity().z));
				}
			}
		}
	}

}
